<?php

// global $link;



require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.head.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/index.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.foot.php');
