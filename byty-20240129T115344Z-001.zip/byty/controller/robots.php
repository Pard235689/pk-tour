<?php

header('Content-Type: text/plain; charset=utf-8');

echo "User-agent: *\nAllow: /\n\n";
echo "Sitemap: https://".DOMAIN."/sitemap.xml\n";
