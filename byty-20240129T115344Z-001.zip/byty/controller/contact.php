<?php

// success page and stop
if($success) {
	require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.head.php');
	require($_SERVER['DOCUMENT_ROOT'].'tmpl/contact_success.php');
	require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.foot.php');
	exit;
}

// checking error if form is posted
$ERR = '';
if(!empty($_POST)) {
	if(empty($_POST['name'])) {
		$ERR = 'You need to enter your name';
	}
	
	if(empty($ERR) && empty($_POST['email'])) {
		$ERR = 'You need to enter your email';
	}
	
	if(empty($ERR) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
		$ERR = 'You need to enter a valid email';
	}
	
	if(empty($ERR) && empty($_POST['subject'])) {
		$ERR = 'You need to enter a subject';
	}
	
	if(empty($ERR) && empty($_POST['message'])) {
		$ERR = 'You need to enter your message';
	}
	
	if(empty($ERR)) {
		
		redirect('/contact/success/');
	}
	
}

require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.head.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/contact.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.foot.php');
