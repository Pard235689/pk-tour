<?php

require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.head.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/error404.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.foot.php');
