<?php

require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.head.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/privacy.php');
require($_SERVER['DOCUMENT_ROOT'].'tmpl/inc.foot.php');
